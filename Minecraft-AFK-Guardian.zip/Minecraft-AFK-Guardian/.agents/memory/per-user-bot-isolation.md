---
name: Per-user bot isolation
description: The control room runs one Minecraft bot service per authenticated user.
---

Each authenticated user owns a persisted bot configuration and a separate in-memory MinecraftBotService. Bot routes must require authentication and resolve the service from the session user ID. Authentication passwords are encrypted with the session secret before storage; never return or log them.

**Why:** The dashboard is published as a public website, so a shared singleton would let one visitor change another visitor’s server, username, or credentials.

**How to apply:** Keep new bot controls and status data scoped through the per-user manager. Use a long-running deployment target for 24/7 bot services, and preserve the auth boundary on every bot route.