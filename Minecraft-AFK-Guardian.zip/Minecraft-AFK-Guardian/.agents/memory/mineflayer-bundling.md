---
name: Mineflayer bundling
description: Build constraint for bundling Mineflayer inside the workspace API server.
---

Keep `mineflayer` external to the API server's esbuild bundle and load it from the installed runtime dependency.

**Why:** Bundling Mineflayer's large Minecraft protocol dependency graph caused the API build service to stop before producing output.

**How to apply:** When adding or changing Mineflayer imports, preserve the external dependency entry in the API server build configuration and validate both the bundle and runtime startup.