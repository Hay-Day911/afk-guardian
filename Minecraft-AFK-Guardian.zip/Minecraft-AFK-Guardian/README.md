# Minecraft AFK Bot

A 24/7 Node.js Minecraft AFK bot for cracked/offline-mode servers, with a live web dashboard for status, uptime, reconnect attempts, and recent logs.

## Configuration

Copy `.env.example` to `.env` locally, or add the same variables as Replit Secrets/environment variables:

| Variable | Required | Default | Description |
| --- | --- | --- | --- |
| `SERVER_IP` | Yes | — | Minecraft server hostname or IP address |
| `SERVER_PORT` | No | `25565` | Minecraft server port |
| `BOT_USERNAME` | Yes | — | Bot name shown in-game |
| `BOT_VERSION` | No | Auto-detect | Minecraft version such as `1.20.4`, or `auto` |
| `AUTH_PASSWORD` | No | — | Password for cracked-server `/login`; registration prompts also receive `/register` |

The bot always uses Mineflayer's `auth: "offline"` setting. Do not put a real password in source control.

## What it does

- Connects to an offline-mode Minecraft server and reconnects with exponential backoff after disconnects, kicks, and errors.
- Performs small anti-AFK actions every 30–60 seconds: jump, turn, and swing.
- Sends `/login <password>` two seconds after spawn when `AUTH_PASSWORD` is configured.
- Responds to private `status`, `ping`, or `online` messages with `I am online!`.
- Responds to public `!status` messages with `I am online!`.
- Serves the dashboard through the web artifact and the API through `/api`.
- Exposes `GET /api/healthz` for uptime monitors. `GET /api/bot/status` and `GET /api/bot/logs` power the dashboard.

## Run

Start the API and web workflows from the Replit workspace. The dashboard is available at the web preview, and the API health check is:

```text
/api/healthz
```

The API server uses the workspace `PORT` supplied by its workflow. The standalone Node entry point is `artifacts/api-server/src/index.ts`, compiled by the package build script.