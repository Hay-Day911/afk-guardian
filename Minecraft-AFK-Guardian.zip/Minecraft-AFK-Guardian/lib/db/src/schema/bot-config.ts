import { pgTable, integer, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const botConfigsTable = pgTable("bot_configs", {
  userId: varchar("user_id").primaryKey().references(() => usersTable.id, { onDelete: "cascade" }),
  serverIp: text("server_ip").notNull(),
  serverPort: integer("server_port").notNull(),
  botUsername: text("bot_username").notNull(),
  botVersion: text("bot_version").notNull(),
  authPasswordEncrypted: text("auth_password_encrypted"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

import { usersTable } from "./auth";