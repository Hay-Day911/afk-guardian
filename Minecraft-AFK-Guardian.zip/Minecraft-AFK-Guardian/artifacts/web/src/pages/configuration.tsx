import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  AlertTriangle,
  Check,
  ChevronLeft,
  CircleHelp,
  Eye,
  EyeOff,
  LoaderCircle,
  LockKeyhole,
  Save,
  Server,
  ShieldCheck,
  UserRound,
  Wifi,
} from 'lucide-react';
import {
  getGetBotConfigQueryKey,
  getGetBotStatusQueryKey,
  getGetBotLogsQueryKey,
  useGetBotConfig,
  useGetBotStatus,
  useUpdateBotConfig,
  type BotConfigInput,
} from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Sidebar } from './dashboard';

type FormState = {
  serverIp: string;
  serverPort: string;
  botUsername: string;
  botVersion: string;
  authPassword: string;
  clearAuthPassword: boolean;
};

const emptyForm: FormState = {
  serverIp: '',
  serverPort: '25565',
  botUsername: '',
  botVersion: 'auto',
  authPassword: '',
  clearAuthPassword: false,
};

function Field({
  label,
  hint,
  icon,
  children,
}: {
  label: string;
  hint?: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <label className="config-field">
      <span className="config-label">
        <span className="config-label-main">{icon}{label}</span>
        {hint && <span className="config-hint">{hint}</span>}
      </span>
      {children}
    </label>
  );
}

export default function Configuration() {
  const queryClient = useQueryClient();
  const configQuery = useGetBotConfig({
    query: {
      queryKey: getGetBotConfigQueryKey(),
    },
  });
  const statusQuery = useGetBotStatus({
    query: {
      queryKey: getGetBotStatusQueryKey(),
      refetchInterval: 4000,
      refetchIntervalInBackground: true,
    },
  });
  const updateMutation = useUpdateBotConfig();
  const [form, setForm] = useState<FormState>(emptyForm);
  const [showPassword, setShowPassword] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (!configQuery.data) return;
    setForm((current) => ({
      ...current,
      serverIp: configQuery.data.serverIp,
      serverPort: String(configQuery.data.serverPort),
      botUsername: configQuery.data.botUsername,
      botVersion: configQuery.data.botVersion || 'auto',
    }));
  }, [configQuery.data]);

  const setField = <K extends keyof FormState>(field: K, value: FormState[K]) => {
    setForm((current) => ({ ...current, [field]: value }));
    setFeedback(null);
    setFormError(null);
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const serverPort = Number(form.serverPort);
    if (!form.serverIp.trim() || !form.botUsername.trim()) {
      setFormError('Server address and bot username are required.');
      return;
    }
    if (!Number.isInteger(serverPort) || serverPort < 1 || serverPort > 65535) {
      setFormError('Enter a valid port from 1 to 65535.');
      return;
    }

    const payload: BotConfigInput = {
      serverIp: form.serverIp.trim(),
      serverPort,
      botUsername: form.botUsername.trim(),
      botVersion: form.botVersion.trim() || 'auto',
      authPassword: form.authPassword || null,
      clearAuthPassword: form.clearAuthPassword,
    };

    setFeedback(null);
    setFormError(null);
    updateMutation.mutate(
      { data: payload },
      {
        onSuccess: (result) => {
          setFeedback(result.message);
          setForm((current) => ({ ...current, authPassword: '', clearAuthPassword: false }));
          void queryClient.invalidateQueries({ queryKey: getGetBotConfigQueryKey() });
          void queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
          void queryClient.invalidateQueries({ queryKey: getGetBotLogsQueryKey({ limit: 80 }) });
        },
        onError: () => setFormError('The configuration could not be saved. Check the values and try again.'),
      },
    );
  };

  const config = configQuery.data;
  const isLoading = configQuery.isLoading;

  return (
    <div className="app-shell">
      <Sidebar state={statusQuery.data?.connectionState} />
      <main className="main-panel">
        <header className="topbar">
          <div className="breadcrumb"><span>CONTROL ROOM</span><span className="breadcrumb-slash">/</span><strong>CONFIGURATION</strong></div>
          <div className="topbar-actions">
            <div className="health-chip"><span className="health-dot" /> runtime settings</div>
            <Link className="icon-button config-back-button" href="/" aria-label="Back to live overview">
              <ChevronLeft size={17} />
            </Link>
          </div>
        </header>

        {isLoading ? (
          <div className="content-wrap config-loading">
            <LoaderCircle className="status-icon-spin" size={22} />
            <span>Reading current configuration…</span>
          </div>
        ) : configQuery.isError || !config ? (
          <div className="content-wrap error-layout">
            <div className="error-symbol"><AlertTriangle size={24} /></div>
            <div className="page-kicker">CONFIGURATION UNAVAILABLE</div>
            <h1 className="error-title">The settings could not load.</h1>
            <p className="error-copy">The API did not return the current bot configuration. Try again from the overview.</p>
            <Link className="button button-dark" href="/">Return to overview</Link>
          </div>
        ) : (
          <div className="content-wrap">
            <div className="page-heading config-heading">
              <div className="page-kicker">MINECRAFT SESSION / RUNTIME SETTINGS</div>
              <div className="heading-row">
                <div>
                  <h1>Set the relay <em>once.</em></h1>
                  <p className="page-summary">Connection details live here. Save changes to restart the bot with a clean session.</p>
                </div>
                <div className="config-state-chip"><span className="read-pulse" /> settings are live</div>
              </div>
            </div>

            <form className="config-layout" onSubmit={handleSubmit}>
              <section className="config-card config-card-main">
                <div className="config-card-heading">
                  <div>
                    <div className="section-tag">Server connection</div>
                    <h2>Where should the bot go?</h2>
                  </div>
                  <div className="config-card-icon"><Server size={18} /></div>
                </div>
                <div className="config-fields-grid">
                  <Field label="Server address" hint="IP or hostname" icon={<Wifi size={14} />}>
                    <input
                      className="config-input"
                      value={form.serverIp}
                      onChange={(event) => setField('serverIp', event.target.value)}
                      placeholder="play.example.net"
                      autoComplete="off"
                      data-testid="input-server-ip"
                    />
                  </Field>
                  <Field label="Port" hint="1–65535" icon={<span className="config-port-mark">#</span>}>
                    <input
                      className="config-input"
                      type="number"
                      min="1"
                      max="65535"
                      value={form.serverPort}
                      onChange={(event) => setField('serverPort', event.target.value)}
                      data-testid="input-server-port"
                    />
                  </Field>
                </div>
                <Field label="Minecraft version" hint="Use auto unless pinned" icon={<CircleHelp size={14} />}>
                  <input
                    className="config-input"
                    value={form.botVersion}
                    onChange={(event) => setField('botVersion', event.target.value)}
                    placeholder="auto"
                    autoComplete="off"
                    data-testid="input-bot-version"
                  />
                </Field>
                <div className="config-note"><Wifi size={15} /><span>Mineflayer will use offline authentication for cracked servers.</span></div>
              </section>

              <section className="config-card config-card-identity">
                <div className="config-card-heading">
                  <div>
                    <div className="section-tag">Bot identity</div>
                    <h2>Who is joining?</h2>
                  </div>
                  <div className="config-card-icon config-card-icon-blue"><UserRound size={18} /></div>
                </div>
                <Field label="Bot username" hint="In-game name" icon={<UserRound size={14} />}>
                  <input
                    className="config-input"
                    value={form.botUsername}
                    onChange={(event) => setField('botUsername', event.target.value)}
                    placeholder="afk-helper"
                    autoComplete="off"
                    data-testid="input-bot-username"
                  />
                </Field>
                <div className="identity-preview">
                  <div className="identity-preview-mark"><UserRound size={17} /></div>
                  <div><span className="mono-label">CURRENT NAME</span><strong>{form.botUsername || 'Not configured'}</strong></div>
                </div>
              </section>

              <section className="config-card config-card-auth">
                <div className="config-card-heading">
                  <div>
                    <div className="section-tag">Optional server auth</div>
                    <h2>Keep the account signed in.</h2>
                  </div>
                  <div className={`config-auth-badge ${config.authConfigured ? 'config-auth-badge-ready' : ''}`}>
                    <ShieldCheck size={14} /> {config.authConfigured ? 'saved' : 'not set'}
                  </div>
                </div>
                <Field label="Auth password" hint={config.authConfigured ? 'Leave blank to keep saved password' : 'Stored only in the running service'} icon={<LockKeyhole size={14} />}>
                  <div className="config-password-wrap">
                    <input
                      className="config-input"
                      type={showPassword ? 'text' : 'password'}
                      value={form.authPassword}
                      onChange={(event) => setField('authPassword', event.target.value)}
                      placeholder={config.authConfigured ? 'Saved password' : 'Optional'}
                      autoComplete="new-password"
                      disabled={form.clearAuthPassword}
                      data-testid="input-auth-password"
                    />
                    <button className="config-password-toggle" type="button" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? 'Hide password' : 'Show password'}>
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </Field>
                <label className="config-checkbox-row">
                  <input type="checkbox" checked={form.clearAuthPassword} onChange={(event) => setField('clearAuthPassword', event.target.checked)} />
                  <span>Clear the saved password</span>
                </label>
                <div className="config-note config-note-copper"><LockKeyhole size={15} /><span>Passwords never appear in the dashboard or logs.</span></div>
              </section>

              <div className="config-actions">
                <div className="config-action-copy">
                  {formError ? <span className="config-feedback config-feedback-error"><AlertTriangle size={14} />{formError}</span> : feedback ? <span className="config-feedback"><Check size={14} />{feedback}</span> : <span>Saving will reconnect the bot with these settings.</span>}
                </div>
                <button className="button button-lime config-save-button" type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? <LoaderCircle size={16} className="status-icon-spin" /> : <Save size={16} />}
                  {updateMutation.isPending ? 'Saving settings' : 'Save & reconnect'}
                </button>
              </div>
            </form>

            <footer className="page-footer"><span>OBSIDIAN RELAY / CONFIGURATION</span><span className="footer-status"><i /> {statusQuery.data?.connectionState ?? 'reading'} session</span><span><LockKeyhole size={13} /> runtime-only changes</span></footer>
          </div>
        )}
      </main>
    </div>
  );
}