import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  Check,
  CircleStop,
  Clock3,
  Cloud,
  Cpu,
  Link2,
  LoaderCircle,
  LogOut,
  RefreshCw,
  RotateCw,
  Server,
  Settings2,
  ShieldCheck,
  Terminal,
  Wifi,
  WifiOff,
  Youtube,
  Zap,
} from 'lucide-react';
import { useAuth } from '@workspace/replit-auth-web';
import { Link, useLocation } from 'wouter';
import {
  getGetBotLogsQueryKey,
  getGetBotStatusQueryKey,
  getHealthCheckQueryKey,
  useGetBotLogs,
  useGetBotStatus,
  useHealthCheck,
  useReconnectBot,
  type BotLogEntry,
  type BotStatus,
} from '@workspace/api-client-react';

const logParams = { limit: 80 };

const connectionCopy: Record<BotStatus['connectionState'], { label: string; detail: string }> = {
  online: { label: 'Online', detail: 'Session is holding steady' },
  connecting: { label: 'Connecting', detail: 'Negotiating a new session' },
  offline: { label: 'Offline', detail: 'Waiting for the next attempt' },
  stopped: { label: 'Stopped', detail: 'Bot process is not running' },
};

function formatUptime(seconds: number) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  if (days > 0) return `${days}d ${hours}h ${minutes}m`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m ${remainingSeconds}s`;
}

function formatRelativeTime(dateString: string | null) {
  if (!dateString) return 'No record';
  const timestamp = new Date(dateString).getTime();
  if (Number.isNaN(timestamp)) return 'Unknown';
  const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  if (seconds < 5) return 'Just now';
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}

function formatTimestamp(dateString: string) {
  const date = new Date(dateString);
  if (Number.isNaN(date.getTime())) return '--:--:--';
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}

function SkeletonBlock({ className }: { className: string }) {
  return <div className={`skeleton-block ${className}`} aria-hidden="true" />;
}

function StatusMark({ state }: { state: BotStatus['connectionState'] }) {
  if (state === 'online') return <span className="status-orb status-orb-online" />;
  if (state === 'connecting') return <LoaderCircle className="status-icon status-icon-spin" aria-hidden="true" />;
  if (state === 'offline') return <WifiOff className="status-icon" aria-hidden="true" />;
  return <CircleStop className="status-icon" aria-hidden="true" />;
}

function LogRow({ entry, index }: { entry: BotLogEntry; index: number }) {
  const tone = entry.level === 'error' ? 'log-error' : entry.level === 'warn' ? 'log-warn' : 'log-info';
  return (
    <div className={`log-row ${tone}`} data-testid={`row-log-${index}`}>
      <span className="log-time" data-testid={`text-log-time-${index}`}>{formatTimestamp(entry.timestamp)}</span>
      <span className="log-level" data-testid={`text-log-level-${index}`}>{entry.level}</span>
      <span className="log-message" data-testid={`text-log-message-${index}`}>{entry.message}</span>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="content-wrap" data-testid="loading-dashboard">
      <div className="page-heading">
        <SkeletonBlock className="skeleton-kicker" />
        <SkeletonBlock className="skeleton-title" />
      </div>
      <div className="hero-grid">
        <SkeletonBlock className="skeleton-hero" />
        <SkeletonBlock className="skeleton-identity" />
      </div>
      <div className="metrics-grid">
        <SkeletonBlock className="skeleton-metric" />
        <SkeletonBlock className="skeleton-metric" />
        <SkeletonBlock className="skeleton-metric" />
        <SkeletonBlock className="skeleton-metric" />
      </div>
    </div>
  );
}

export function Sidebar({ state }: { state?: BotStatus['connectionState'] }) {
  const [location] = useLocation();
  const auth = useAuth();
  const isOverview = location === '/';
  const isConfiguration = location === '/config';

  return (
    <aside className="sidebar">
      <div className="brand-lockup">
        <div className="brand-mark"><span /><span /><span /></div>
        <div>
          <div className="brand-name">OBSIDIAN</div>
          <div className="brand-subtitle">relay control</div>
        </div>
      </div>
      <div className="sidebar-rule" />
      <div className="nav-label">Workspace</div>
      <div className="sidebar-nav">
        <Link className={`nav-item ${isOverview ? 'nav-item-active' : ''}`} href="/" data-testid="nav-overview">
          <Activity size={16} strokeWidth={2.2} />
          <span>Live overview</span>
          {isOverview && <span className="nav-live-dot" />}
        </Link>
        <Link className={`nav-item ${isConfiguration ? 'nav-item-active' : ''}`} href="/config" data-testid="nav-configuration">
          <Settings2 size={16} strokeWidth={2.2} />
          <span>Configuration</span>
          {isConfiguration && <span className="nav-live-dot" />}
        </Link>
      </div>
      <div className="sidebar-spacer" />
      <div className="rail-card">
        <div className="rail-card-top"><span className="rail-pulse" /> Relay status</div>
        <div className="rail-card-value">{state === 'online' ? 'Holding connection' : state ? connectionCopy[state].detail : 'Reading session'}</div>
        <div className="rail-card-foot"><span>polling 4s</span><span className="rail-signal"><i /><i /><i /><i /></span></div>
      </div>
      <a
        className="youtube-cta"
        href="https://youtube.com/@hussein7203?si=vSUJuGu3RctwJK8S"
        target="_blank"
        rel="noreferrer"
        aria-label="Subscribe to Hussein7203 on YouTube"
      >
        <img src="/youtube-profile.png" alt="Hussein7203 YouTube profile" className="youtube-cta-avatar" />
        <span className="youtube-cta-copy">
          <span className="youtube-cta-label">Creator channel</span>
          <strong>Subscribe on YouTube</strong>
        </span>
        <Youtube size={15} strokeWidth={2.2} aria-hidden="true" />
      </a>
      <div className="sidebar-footer">
        <div className="sidebar-user">
          <span className="sidebar-user-name">{auth.user?.firstName || auth.user?.email || 'Signed in'}</span>
          <button className="sidebar-logout" onClick={auth.logout}>Log out</button>
        </div>
        <div className="footer-line"><span className="footer-key">MODE</span><span>OFFLINE-AUTH</span></div>
        <div className="footer-line"><span className="footer-key">BUILD</span><span>0.8.4 / LOCAL</span></div>
      </div>
    </aside>
  );
}

export default function Dashboard() {
  const queryClient = useQueryClient();
  const [lastAction, setLastAction] = useState<string | null>(null);
  const statusQuery = useGetBotStatus({
    query: {
      queryKey: getGetBotStatusQueryKey(),
      refetchInterval: 4000,
      refetchIntervalInBackground: true,
    },
  });
  const logsQuery = useGetBotLogs(logParams, {
    query: {
      queryKey: getGetBotLogsQueryKey(logParams),
      refetchInterval: 5000,
      refetchIntervalInBackground: true,
    },
  });
  const healthQuery = useHealthCheck({
    query: {
      queryKey: getHealthCheckQueryKey(),
      refetchInterval: 15000,
      refetchIntervalInBackground: true,
    },
  });
  const reconnectMutation = useReconnectBot();
  const status = statusQuery.data;
  const logs = logsQuery.data ?? [];
  const state = status?.connectionState;
  const statusMeta = state ? connectionCopy[state] : connectionCopy.offline;
  const isInitialLoading = statusQuery.isLoading;

  const refreshAll = () => {
    void Promise.all([statusQuery.refetch(), logsQuery.refetch(), healthQuery.refetch()]);
  };

  const handleReconnect = () => {
    setLastAction(null);
    reconnectMutation.mutate(undefined, {
      onSuccess: (result) => {
        setLastAction(result.message);
        void queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetBotLogsQueryKey(logParams) });
      },
      onError: () => setLastAction('Reconnect request could not be sent. Try again.'),
    });
  };

  return (
    <div className="app-shell">
      <Sidebar state={state} />
      <main className="main-panel">
        <header className="topbar">
          <div className="breadcrumb"><span>CONTROL ROOM</span><span className="breadcrumb-slash">/</span><strong>LIVE OVERVIEW</strong></div>
          <div className="topbar-actions">
            <div className={`health-chip ${healthQuery.isError ? 'health-chip-error' : ''}`} data-testid="status-health">
              <span className="health-dot" />
              {healthQuery.isError ? 'API degraded' : healthQuery.data?.status ?? 'checking API'}
            </div>
            <button className="icon-button" onClick={refreshAll} aria-label="Refresh dashboard" data-testid="button-refresh-dashboard">
              <RefreshCw size={16} className={statusQuery.isFetching ? 'icon-spin-soft' : ''} />
            </button>
          </div>
        </header>

        {isInitialLoading ? <DashboardSkeleton /> : statusQuery.isError || !status ? (
          <div className="content-wrap error-layout" data-testid="error-dashboard">
            <div className="error-symbol"><WifiOff size={24} /></div>
            <div className="page-kicker">STATUS FEED UNAVAILABLE</div>
            <h1 className="error-title">The relay is quiet.</h1>
            <p className="error-copy">We could not read the bot session. The API may be restarting or the control process may be offline.</p>
            <button className="button button-dark" onClick={() => void statusQuery.refetch()} data-testid="button-retry-status">
              <RotateCw size={16} /> Retry status read
            </button>
          </div>
        ) : (
          <div className="content-wrap">
            <div className="page-heading">
              <div className="page-kicker">MINECRAFT SESSION / {status.serverIp}</div>
              <div className="heading-row">
                <div>
                  <h1 data-testid="heading-dashboard">The connection, <em>without</em> the guesswork.</h1>
                  <p className="page-summary">A live read on the little process keeping your world occupied.</p>
                </div>
                <div className="last-read"><span className="read-pulse" /> refreshed {formatRelativeTime(statusQuery.dataUpdatedAt ? new Date(statusQuery.dataUpdatedAt).toISOString() : null)}</div>
              </div>
            </div>

            <section className="hero-grid" aria-label="Current bot connection">
              <div className={`status-card status-card-${state}`}>
                <div className="status-card-top">
                  <span className="section-tag">Connection state</span>
                  <span className="status-code">0{state === 'online' ? '1' : state === 'connecting' ? '2' : '0'}</span>
                </div>
                <div className="state-display">
                  <div className="state-mark"><StatusMark state={status.connectionState} /></div>
                  <div>
                    <div className="state-label" data-testid="status-connection-state">{statusMeta.label}</div>
                    <div className="state-detail">{statusMeta.detail}</div>
                  </div>
                </div>
                <div className="state-footer">
                  <div className="state-footer-copy">
                    <span className="mono-label">LAST CONNECTED</span>
                    <strong>{formatRelativeTime(status.lastConnectedAt)}</strong>
                  </div>
                  <button
                    className="button button-lime"
                    onClick={handleReconnect}
                    disabled={reconnectMutation.isPending}
                    data-testid="button-reconnect-bot"
                  >
                    {reconnectMutation.isPending ? <LoaderCircle size={16} className="status-icon-spin" /> : <Link2 size={16} />}
                    {reconnectMutation.isPending ? 'Requesting' : 'Reconnect bot'}
                    <ArrowUpRight size={15} />
                  </button>
                </div>
                {lastAction && <div className="action-feedback" data-testid="status-reconnect-feedback"><Check size={14} /> {lastAction}</div>}
              </div>

              <div className="identity-card">
                <div className="identity-header">
                  <div className="section-tag">Bot identity</div>
                  <div className="identity-icon"><Cpu size={18} /></div>
                </div>
                <div className="identity-name" data-testid="text-bot-username">{status.botUsername}</div>
                <div className="identity-meta">
                  <span><Server size={14} /> {status.serverIp}:{status.serverPort}</span>
                  <span><Terminal size={14} /> {status.botVersion ?? 'Version pending'}</span>
                </div>
                <div className="identity-line" />
                <div className="identity-detail-grid">
                  <div><span className="mono-label">SESSION STARTED</span><strong>{formatRelativeTime(status.startedAt)}</strong></div>
                  <div><span className="mono-label">LAST DROPPED</span><strong>{formatRelativeTime(status.lastDisconnectedAt)}</strong></div>
                </div>
              </div>
            </section>

            <section className="metrics-grid" aria-label="Bot metrics">
              <div className="metric-card metric-card-featured" data-testid="metric-uptime">
                <div className="metric-icon"><Clock3 size={17} /></div>
                <div className="metric-label">Uptime this run</div>
                <div className="metric-value">{formatUptime(status.uptimeSeconds)}</div>
                <div className="metric-sub">since process start</div>
              </div>
              <div className="metric-card" data-testid="metric-reconnect-attempt">
                <div className="metric-icon metric-icon-copper"><RotateCw size={17} /></div>
                <div className="metric-label">Reconnect attempts</div>
                <div className="metric-value">{status.reconnectAttempt}</div>
                <div className="metric-sub">{status.nextReconnectSeconds > 0 ? `next in ${status.nextReconnectSeconds}s` : 'no attempt queued'}</div>
              </div>
              <div className="metric-card" data-testid="metric-auth">
                <div className="metric-icon metric-icon-blue"><ShieldCheck size={17} /></div>
                <div className="metric-label">Auth profile</div>
                <div className="metric-value metric-value-word">{status.authConfigured ? 'Ready' : 'Missing'}</div>
                <div className="metric-sub">{status.authConfigured ? 'offline-mode enabled' : 'credentials required'}</div>
              </div>
              <div className="metric-card" data-testid="metric-anti-afk">
                <div className="metric-icon metric-icon-lime"><Zap size={17} /></div>
                <div className="metric-label">Anti-AFK routine</div>
                 <div className="metric-value metric-value-word">{status.sleeping ? 'Sleeping' : status.antiAfkEnabled ? 'Active' : 'Paused'}</div>
                 <div className="metric-sub">{status.sleeping ? 'resting in nearest bed' : status.antiAfkEnabled ? 'movement loop armed' : 'no movement loop'}</div>
              </div>
            </section>

            <section className="lower-grid">
              <div className="logs-card">
                <div className="card-heading">
                  <div>
                    <div className="section-tag">Event stream</div>
                    <h2>Recent logs</h2>
                  </div>
                  <div className="log-count" data-testid="text-log-count">{logs.length.toString().padStart(2, '0')} events</div>
                </div>
                {logsQuery.isError ? (
                  <div className="inline-state" data-testid="error-logs"><AlertTriangle size={17} /><span>Log stream unavailable.</span><button onClick={() => void logsQuery.refetch()} data-testid="button-retry-logs">Retry</button></div>
                ) : logs.length === 0 ? (
                  <div className="empty-logs" data-testid="empty-logs"><Terminal size={20} /><strong>No events yet</strong><span>Connection events will appear here as the relay works.</span></div>
                ) : (
                  <div className="log-list" data-testid="list-logs">{logs.map((entry, index) => <LogRow key={`${entry.timestamp}-${index}`} entry={entry} index={index} />)}</div>
                )}
              </div>

              <div className="details-card">
                <div className="card-heading">
                  <div>
                    <div className="section-tag">Session telemetry</div>
                    <h2>At a glance</h2>
                  </div>
                  <Wifi size={19} className="heading-icon" />
                </div>
                <div className="telemetry-list">
                  <div className="telemetry-row"><span>Transport</span><strong>TCP / Minecraft</strong><span className="telemetry-state"><i /> stable</span></div>
                  <div className="telemetry-row"><span>Target port</span><strong>{status.serverPort}</strong><span className="telemetry-neutral">configured</span></div>
                  <div className="telemetry-row"><span>Offline auth</span><strong>{status.authConfigured ? 'configured' : 'not configured'}</strong><span className={status.authConfigured ? 'telemetry-state' : 'telemetry-warn'}><i /> {status.authConfigured ? 'ready' : 'attention'}</span></div>
                  <div className="telemetry-row"><span>Last disconnect</span><strong>{formatRelativeTime(status.lastDisconnectedAt)}</strong><span className="telemetry-neutral">observed</span></div>
                </div>
                <div className="details-note"><Cloud size={16} /><span>Polling every 4 seconds while this tab is open.</span></div>
              </div>
            </section>
            <footer className="page-footer"><span>OBSIDIAN RELAY / BOT CONTROL ROOM</span><span className="footer-status"><i /> {healthQuery.isError ? 'health check attention' : 'all systems reporting'}</span><span><LogOut size={13} /> session-local monitor</span></footer>
          </div>
        )}
      </main>
    </div>
  );
}