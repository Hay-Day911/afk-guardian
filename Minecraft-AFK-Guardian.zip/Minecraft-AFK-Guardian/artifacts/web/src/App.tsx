import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import Dashboard from '@/pages/dashboard';
import Configuration from '@/pages/configuration';
import { LogIn, LoaderCircle } from 'lucide-react';
import { useAuth } from '@workspace/replit-auth-web';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/config" component={Configuration} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  const auth = useAuth();

  if (auth.isLoading) {
    return (
      <div className="auth-screen">
        <LoaderCircle className="status-icon-spin" size={24} />
        <span>Checking your session…</span>
      </div>
    );
  }

  if (!auth.isAuthenticated) {
    return (
      <div className="auth-screen">
        <div className="auth-panel">
          <div className="brand-lockup">
            <div className="brand-mark"><span /><span /><span /></div>
            <div>
              <div className="brand-name">OBSIDIAN</div>
              <div className="brand-subtitle">relay control</div>
            </div>
          </div>
          <div className="page-kicker">PRIVATE BOT CONTROL ROOM</div>
          <h1>Sign in to manage <em>your</em> bot.</h1>
          <p>Every account gets its own Minecraft connection, configuration, and event stream.</p>
          <button className="button button-lime auth-login-button" onClick={auth.login}>
            <LogIn size={16} /> Sign in
          </button>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
