import "dotenv/config";

import mineflayer, { type Bot } from "mineflayer";
import pathfinderPackage from "mineflayer-pathfinder";
import { logger } from "./logger";

const { goals, Movements, pathfinder } = pathfinderPackage;

type ConnectionState = "online" | "connecting" | "offline" | "stopped";
type LogLevel = "info" | "warn" | "error";

export type BotLogEntry = {
  timestamp: string;
  level: LogLevel;
  message: string;
};

export type BotConfigValues = {
  serverIp: string;
  serverPort: number;
  botUsername: string;
  botVersion: string;
  authPassword: string;
};

export type BotConfigInput = {
  serverIp: string;
  serverPort: number;
  botUsername: string;
  botVersion: string;
  authPassword?: string | null;
  clearAuthPassword?: boolean;
};

const MAX_LOGS = 200;
const MIN_ANTI_AFK_DELAY_MS = 30_000;
const MAX_ANTI_AFK_DELAY_MS = 60_000;
const AUTH_DELAY_MS = 2_000;
const INITIAL_RECONNECT_DELAY_MS = 2_000;
const MAX_RECONNECT_DELAY_MS = 60_000;
const HIBERNATION_RETRY_DELAY_MS = 10_000;
const BED_SEARCH_DISTANCE = 48;
const BED_RETRY_DELAY_MS = 60_000;

function parsePort(rawPort: string | undefined): number {
  const port = Number(rawPort ?? 25565);
  return Number.isInteger(port) && port > 0 && port <= 65535 ? port : 25565;
}

function formatUptime(totalSeconds: number): number {
  return Math.max(0, Math.floor(totalSeconds));
}

class MinecraftBotService {
  private bot: Bot | null = null;
  private antiAfkTimer: NodeJS.Timeout | null = null;
  private authTimer: NodeJS.Timeout | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private bedTimer: NodeJS.Timeout | null = null;
  private connectionState: ConnectionState = "stopped";
  private reconnectAttempt = 0;
  private nextReconnectAt: number | null = null;
  private connectedAt: number | null = null;
  private sleeping = false;
  private lastConnectedAt: string | null = null;
  private lastDisconnectedAt: string | null = null;
  private readonly startedAt = new Date().toISOString();
  private readonly logs: BotLogEntry[] = [];
  private shouldRun = true;

  private config: BotConfigValues;

  constructor(initialConfig?: Partial<BotConfigValues>) {
    this.config = {
      serverIp: initialConfig?.serverIp?.trim() ?? "",
      serverPort: initialConfig?.serverPort ?? parsePort(process.env.SERVER_PORT),
      botUsername: initialConfig?.botUsername?.trim() ?? "",
      botVersion: initialConfig?.botVersion?.trim() || "auto",
      authPassword: initialConfig?.authPassword?.trim() ?? "",
    };
  }

  start(): void {
    if (!this.config.serverIp || !this.config.botUsername) {
      this.connectionState = "stopped";
      this.log(
        "error",
        "Bot is stopped: SERVER_IP and BOT_USERNAME are required in the environment.",
      );
      return;
    }

    this.log("info", "Minecraft AFK service started.");
    this.connect("initial startup");
  }

  getStatus() {
    const uptimeSeconds =
      this.connectionState === "online" && this.connectedAt
        ? formatUptime((Date.now() - this.connectedAt) / 1000)
        : 0;

    return {
      connectionState: this.connectionState,
      serverIp: this.config.serverIp || "Not configured",
      serverPort: this.config.serverPort,
      botUsername: this.config.botUsername || "Not configured",
      botVersion:
        this.config.botVersion && this.config.botVersion.toLowerCase() !== "auto"
          ? this.config.botVersion
          : null,
      uptimeSeconds,
      reconnectAttempt: this.reconnectAttempt,
      nextReconnectSeconds: this.nextReconnectAt
        ? Math.max(0, Math.ceil((this.nextReconnectAt - Date.now()) / 1000))
        : 0,
      authConfigured: Boolean(this.config.authPassword),
      antiAfkEnabled: this.connectionState === "online",
      sleeping: this.sleeping,
      lastConnectedAt: this.lastConnectedAt,
      lastDisconnectedAt: this.lastDisconnectedAt,
      startedAt: this.startedAt,
    };
  }

  getConfig() {
    return {
      serverIp: this.config.serverIp,
      serverPort: this.config.serverPort,
      botUsername: this.config.botUsername,
      botVersion: this.config.botVersion,
      authConfigured: Boolean(this.config.authPassword),
    };
  }

  updateConfig(input: BotConfigInput) {
    this.config = {
      serverIp: input.serverIp.trim(),
      serverPort: input.serverPort,
      botUsername: input.botUsername.trim(),
      botVersion: input.botVersion.trim() || "auto",
      authPassword: input.clearAuthPassword
        ? ""
        : input.authPassword?.trim() || this.config.authPassword,
    };

    this.clearReconnectTimer();
    this.clearAntiAfkTimer();
    this.clearAuthTimer();
    this.clearBedTimer();
    this.reconnectAttempt = 0;
    this.shouldRun = true;
    this.connectionState = "offline";
    this.sleeping = false;
    this.log("info", "Bot configuration updated from the dashboard.");

    if (this.bot) {
      this.bot.end("Configuration updated");
      this.bot = null;
    }

    this.nextReconnectAt = Date.now() + 250;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.nextReconnectAt = null;
      this.connect("configuration update");
    }, 250);

    return {
      ok: true as const,
      message: "Configuration saved. Reconnecting with the new settings.",
      config: this.getConfig(),
    };
  }

  getLogs(limit: number): BotLogEntry[] {
    return this.logs.slice(-limit);
  }

  requestReconnect(): { ok: true; message: string } {
    if (!this.config.serverIp || !this.config.botUsername) {
      return {
        ok: true,
        message: "Reconnect skipped until SERVER_IP and BOT_USERNAME are configured.",
      };
    }

    this.clearReconnectTimer();
    this.clearAntiAfkTimer();
    this.clearAuthTimer();
    this.clearBedTimer();
    this.reconnectAttempt = 0;
    this.nextReconnectAt = Date.now() + 250;
    this.shouldRun = true;
    this.connectionState = "offline";
    this.sleeping = false;
    this.log("info", "Manual reconnect requested from the dashboard.");

    if (this.bot) {
      this.bot.end("Manual reconnect requested");
      this.bot = null;
    }

    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.nextReconnectAt = null;
      this.connect("manual reconnect");
    }, 250);

    return { ok: true, message: "Reconnect requested." };
  }

  private connect(reason: string): void {
    if (
      !this.shouldRun ||
      this.bot ||
      !this.config.serverIp ||
      !this.config.botUsername
    ) {
      return;
    }

    this.connectionState = "connecting";
    this.nextReconnectAt = null;
    this.log(
      "info",
      `Connecting to ${this.config.serverIp}:${this.config.serverPort} as ${this.config.botUsername} (${reason}).`,
    );

    const options: Parameters<typeof mineflayer.createBot>[0] = {
      host: this.config.serverIp,
      port: this.config.serverPort,
      username: this.config.botUsername,
      auth: "offline",
    };

    if (this.config.botVersion && this.config.botVersion.toLowerCase() !== "auto") {
      options.version = this.config.botVersion;
    }

    const bot = mineflayer.createBot(options);
    this.bot = bot;
    bot.loadPlugin(pathfinder);

    bot.once("spawn", () => {
      this.connectionState = "online";
      this.sleeping = false;
      this.connectedAt = Date.now();
      this.lastConnectedAt = new Date().toISOString();
      this.reconnectAttempt = 0;
      this.log("info", "Bot spawned successfully and is online.");
      this.startAntiAfk();
      this.scheduleAuth();
      this.scheduleBedSearch(3_500);
    });

    bot.on("wake", () => {
      if (this.connectionState === "online") {
        this.log("info", "Bot woke up; looking for the nearest bed again.");
        this.startAntiAfk();
        this.scheduleBedSearch();
      }
    });

    bot.on("whisper", (username, message) => {
      if (username === this.config.botUsername || !message.trim()) {
        return;
      }

      if (/^(status|ping|online|\?status)$/i.test(message.trim())) {
        bot.whisper(username, "I am online!");
        this.log("info", `Answered status check from ${username}.`);
      }
    });

    bot.on("chat", (username, message) => {
      if (username === this.config.botUsername) {
        return;
      }

      if (/^!status$/i.test(message.trim())) {
        bot.chat("I am online!");
        this.log("info", `Answered public status check from ${username}.`);
      }
    });

    bot.on("messagestr", (message) => {
      if (!this.config.authPassword || !this.bot || this.connectionState !== "online") {
        return;
      }

      if (/register|create an account|not registered/i.test(message)) {
        this.bot.chat(`/register ${this.config.authPassword} ${this.config.authPassword}`);
        this.log("info", "Sent the server registration command.");
      }
    });

    bot.on("kicked", (reason) => {
      this.log("warn", `Bot was kicked: ${this.safeReason(reason)}.`);
    });

    bot.on("error", (error) => {
      this.log("error", `Bot error: ${error.message}.`);
      this.scheduleReconnect("connection error");
    });

    bot.on("end", (reason) => {
      this.connectedAt = null;
      this.sleeping = false;
      this.lastDisconnectedAt = new Date().toISOString();
      this.clearAntiAfkTimer();
      this.clearAuthTimer();
      this.clearBedTimer();
      if (this.bot === bot) {
        this.bot = null;
      }
      this.connectionState = this.shouldRun ? "offline" : "stopped";
      this.log("warn", `Bot disconnected${reason ? `: ${this.safeReason(reason)}` : "."}`);
      if (this.shouldRun) {
        this.scheduleReconnect("disconnect");
      }
    });
  }

  private scheduleAuth(): void {
    this.clearAuthTimer();
    if (!this.config.authPassword || !this.bot) {
      return;
    }

    this.authTimer = setTimeout(() => {
      this.authTimer = null;
      if (this.bot && this.connectionState === "online") {
        this.bot.chat(`/login ${this.config.authPassword}`);
        this.log("info", "Sent the configured login command.");
      }
    }, AUTH_DELAY_MS);
  }

  private startAntiAfk(): void {
    this.clearAntiAfkTimer();
    this.scheduleAntiAfkAction();
  }

  private scheduleAntiAfkAction(): void {
    const delay =
      MIN_ANTI_AFK_DELAY_MS +
      Math.floor(
        Math.random() * (MAX_ANTI_AFK_DELAY_MS - MIN_ANTI_AFK_DELAY_MS + 1),
      );

    this.antiAfkTimer = setTimeout(() => {
      if (!this.bot || this.connectionState !== "online") {
        return;
      }
      if (this.bot.isSleeping) {
        return;
      }

      this.bot.setControlState("jump", true);
      setTimeout(() => this.bot?.setControlState("jump", false), 450);
      this.bot.swingArm("right");
      void this.bot.look(
        this.bot.entity.yaw + (Math.random() > 0.5 ? 0.35 : -0.35),
        this.bot.entity.pitch,
        true,
      );
      this.log("info", "Anti-AFK movement completed.");
      this.scheduleAntiAfkAction();
    }, delay);
  }

  private scheduleReconnect(reason: string): void {
    if (!this.shouldRun || this.reconnectTimer) {
      return;
    }

    const delay = Math.min(
      MAX_RECONNECT_DELAY_MS,
      this.reconnectAttempt === 0
        ? INITIAL_RECONNECT_DELAY_MS
        : Math.max(
            HIBERNATION_RETRY_DELAY_MS,
            INITIAL_RECONNECT_DELAY_MS * 2 ** this.reconnectAttempt,
          ),
    );
    this.reconnectAttempt += 1;
    this.nextReconnectAt = Date.now() + delay;
    this.connectionState = "offline";
    this.log(
      "warn",
      `Reconnect attempt ${this.reconnectAttempt} scheduled in ${Math.ceil(delay / 1000)}s (${reason}).`,
    );

    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.nextReconnectAt = null;
      this.connect("automatic reconnect");
    }, delay);
  }

  private clearAntiAfkTimer(): void {
    if (this.antiAfkTimer) {
      clearTimeout(this.antiAfkTimer);
      this.antiAfkTimer = null;
    }
  }

  private clearAuthTimer(): void {
    if (this.authTimer) {
      clearTimeout(this.authTimer);
      this.authTimer = null;
    }
  }

  private scheduleBedSearch(delay = BED_RETRY_DELAY_MS): void {
    this.clearBedTimer();
    this.bedTimer = setTimeout(() => {
      this.bedTimer = null;
      this.findAndUseNearestBed();
    }, delay);
  }

  private findAndUseNearestBed(): void {
    const bot = this.bot;
    if (!bot || this.connectionState !== "online" || bot.isSleeping) {
      return;
    }

    const bed = bot.findBlock({
      maxDistance: BED_SEARCH_DISTANCE,
      matching: (block) => block.name.endsWith("_bed"),
    });

    if (!bed) {
      this.scheduleBedSearch();
      return;
    }

    const distance = bot.entity.position.distanceTo(bed.position);
    if (distance <= 3.5) {
      void this.sleepAtBed(bot, bed);
      return;
    }

    const movement = new Movements(bot);
    movement.allow1by1towers = false;
    bot.pathfinder.setMovements(movement);
    bot.pathfinder.setGoal(new goals.GoalNear(bed.position.x, bed.position.y, bed.position.z, 2));
    this.log("info", "Found a nearby bed; walking to it.");

    const timeout = setTimeout(() => {
      if (this.bot === bot && this.connectionState === "online" && !bot.isSleeping) {
        bot.pathfinder.stop();
        this.scheduleBedSearch();
      }
    }, 30_000);

    bot.once("goal_reached", () => {
      clearTimeout(timeout);
      if (this.bot === bot && this.connectionState === "online") {
        void this.sleepAtBed(bot, bed);
      }
    });
  }

  private async sleepAtBed(bot: Bot, bed: NonNullable<ReturnType<Bot["findBlock"]>>): Promise<void> {
    try {
      await bot.sleep(bed);
      this.sleeping = true;
      this.clearAntiAfkTimer();
      this.log("info", "Bot is sleeping in the nearest bed.");
    } catch (error) {
      this.log("warn", `Could not sleep in the nearest bed: ${this.safeReason(error)}.`);
      this.scheduleBedSearch();
    }
  }

  private clearReconnectTimer(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.nextReconnectAt = null;
  }

  private clearBedTimer(): void {
    if (this.bedTimer) {
      clearTimeout(this.bedTimer);
      this.bedTimer = null;
    }
  }

  private safeReason(reason: unknown): string {
    if (typeof reason === "string") {
      return reason.replace(/\s+/g, " ").slice(0, 180);
    }
    try {
      return JSON.stringify(reason).slice(0, 180);
    } catch {
      return "unknown reason";
    }
  }

  private log(level: LogLevel, message: string): void {
    const entry = {
      timestamp: new Date().toISOString(),
      level,
      message,
    };
    this.logs.push(entry);
    if (this.logs.length > MAX_LOGS) {
      this.logs.shift();
    }

    if (level === "error") {
      logger.error({ service: "minecraft-bot" }, message);
    } else if (level === "warn") {
      logger.warn({ service: "minecraft-bot" }, message);
    } else {
      logger.info({ service: "minecraft-bot" }, message);
    }
  }
}

export { MinecraftBotService };