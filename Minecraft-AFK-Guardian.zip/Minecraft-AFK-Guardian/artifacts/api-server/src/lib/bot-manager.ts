import crypto from "node:crypto";
import { botConfigsTable, db } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  MinecraftBotService,
  type BotConfigInput,
  type BotConfigValues,
} from "./minecraft-bot";

function encryptionKey(): Buffer {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    throw new Error("SESSION_SECRET is required to encrypt bot passwords.");
  }
  return crypto.scryptSync(secret, "obsidian-relay-bot-config", 32);
}

function encryptPassword(password: string): string | null {
  if (!password) return null;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(password, "utf8"), cipher.final()]);
  return [iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), encrypted.toString("base64url")].join(".");
}

function decryptPassword(payload: string | null): string {
  if (!payload) return "";
  const [ivText, tagText, encryptedText] = payload.split(".");
  if (!ivText || !tagText || !encryptedText) throw new Error("Stored bot password is invalid.");
  const decipher = crypto.createDecipheriv(
    "aes-256-gcm",
    encryptionKey(),
    Buffer.from(ivText, "base64url"),
  );
  decipher.setAuthTag(Buffer.from(tagText, "base64url"));
  return Buffer.concat([
    decipher.update(Buffer.from(encryptedText, "base64url")),
    decipher.final(),
  ]).toString("utf8");
}

function serviceConfig(row: typeof botConfigsTable.$inferSelect): BotConfigValues {
  return {
    serverIp: row.serverIp,
    serverPort: row.serverPort,
    botUsername: row.botUsername,
    botVersion: row.botVersion,
    authPassword: decryptPassword(row.authPasswordEncrypted),
  };
}

export class MinecraftBotManager {
  private readonly services = new Map<string, MinecraftBotService>();

  async startAll(): Promise<void> {
    const rows = await db.select().from(botConfigsTable);
    for (const row of rows) {
      const service = new MinecraftBotService(serviceConfig(row));
      this.services.set(row.userId, service);
      service.start();
    }
  }

  async getService(userId: string): Promise<MinecraftBotService> {
    const existing = this.services.get(userId);
    if (existing) return existing;

    const [row] = await db.select().from(botConfigsTable).where(eq(botConfigsTable.userId, userId));
    const service = row
      ? new MinecraftBotService(serviceConfig(row))
      : new MinecraftBotService();
    this.services.set(userId, service);
    if (row) service.start();
    return service;
  }

  async updateConfig(userId: string, input: BotConfigInput) {
    const service = await this.getService(userId);
    const current = service.getConfig();
    const password = input.clearAuthPassword
      ? ""
      : input.authPassword?.trim() || (current.authConfigured ? undefined : "");
    const encryptedPassword =
      password === undefined
        ? (await db.select({ encrypted: botConfigsTable.authPasswordEncrypted })
            .from(botConfigsTable)
            .where(eq(botConfigsTable.userId, userId)))[0]?.encrypted ?? null
        : encryptPassword(password);

    const values = {
      userId,
      serverIp: input.serverIp.trim(),
      serverPort: input.serverPort,
      botUsername: input.botUsername.trim(),
      botVersion: input.botVersion.trim() || "auto",
      authPasswordEncrypted: encryptedPassword,
      updatedAt: new Date(),
    };

    await db
      .insert(botConfigsTable)
      .values(values)
      .onConflictDoUpdate({
        target: botConfigsTable.userId,
        set: values,
      });

    return service.updateConfig(input);
  }
}

export const botManager = new MinecraftBotManager();