import { Router, type IRouter } from "express";
import {
  GetBotConfigResponse,
  GetBotLogsQueryParams,
  GetBotLogsResponse,
  GetBotStatusResponse,
  ReconnectBotResponse,
  UpdateBotConfigBody,
  UpdateBotConfigResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/authMiddleware";
import { botManager } from "../lib/bot-manager";

const router: IRouter = Router();

router.use(requireAuth);

router.get("/bot/status", async (req, res) => {
  const service = await botManager.getService(req.user!.id);
  res.json(GetBotStatusResponse.parse(service.getStatus()));
});

router.get("/bot/config", async (req, res) => {
  const service = await botManager.getService(req.user!.id);
  res.json(GetBotConfigResponse.parse(service.getConfig()));
});

router.put("/bot/config", async (req, res) => {
  const input = UpdateBotConfigBody.parse(req.body);
  res.json(UpdateBotConfigResponse.parse(await botManager.updateConfig(req.user!.id, input)));
});

router.get("/bot/logs", async (req, res) => {
  const query = GetBotLogsQueryParams.parse(req.query);
  const service = await botManager.getService(req.user!.id);
  res.json(GetBotLogsResponse.parse(service.getLogs(query.limit)));
});

router.post("/bot/reconnect", async (req, res) => {
  const service = await botManager.getService(req.user!.id);
  res.json(ReconnectBotResponse.parse(service.requestReconnect()));
});

export default router;