import type { AuthUser } from "@workspace/api-zod";
import type { NextFunction, Request, Response } from "express";
import * as oidc from "openid-client";
import {
  clearSession,
  getOidcConfig,
  getSession,
  getSessionId,
  type SessionData,
} from "../lib/auth";

declare global {
  namespace Express {
    interface User extends AuthUser {}
    interface Request {
      isAuthenticated(): this is AuthedRequest;
      user?: User;
    }
    interface AuthedRequest {
      user: User;
    }
  }
}

export async function authMiddleware(req: Request, res: Response, next: NextFunction) {
  req.isAuthenticated = function (this: Request) {
    return this.user != null;
  } as Request["isAuthenticated"];

  const sid = getSessionId(req);
  if (!sid) {
    next();
    return;
  }

  const session = await getSession(sid);
  if (!session?.user?.id) {
    await clearSession(res, sid);
    next();
    return;
  }

  if (session.expires_at && Math.floor(Date.now() / 1000) > session.expires_at) {
    if (!session.refresh_token) {
      await clearSession(res, sid);
      next();
      return;
    }
    try {
      const tokens = await oidc.refreshTokenGrant(await getOidcConfig(), session.refresh_token);
      session.access_token = tokens.access_token;
      session.refresh_token = tokens.refresh_token ?? session.refresh_token;
      session.expires_at = tokens.expiresIn()
        ? Math.floor(Date.now() / 1000) + tokens.expiresIn()!
        : session.expires_at;
    } catch {
      await clearSession(res, sid);
      next();
      return;
    }
  }

  req.user = session.user;
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }
  next();
}